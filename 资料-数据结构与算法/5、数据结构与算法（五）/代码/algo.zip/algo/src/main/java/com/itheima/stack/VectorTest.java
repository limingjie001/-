package com.itheima.stack;

import java.util.Vector;

/**
 * Created by tanshuai on 2019/6/23.
 */
public class VectorTest {
    public static void main(String[] args) {
        //创建vector
        Vector vector = new Vector();
        
        //添加元素
        vector.add("itcast");
        
        //获取元素
        vector.get(0);
    }
}
